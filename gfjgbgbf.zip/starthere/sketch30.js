function setup() {
    createCanvas(640, 640);

}

function draw() {

}